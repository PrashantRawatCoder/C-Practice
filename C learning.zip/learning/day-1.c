﻿#include <stdio.h>

int main()
{
	int a = 1;
	printf("Radhe krishna\n \a");
	printf("%d\n",a);
	scanf("placeholder", a);
	printf("%d\n",a+5);
	return 0;
}

﻿//       C O M P L E A T E D

//Gusses the number

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
	int random,gussed=0,gusses=0;
	srand(time(0));
	random=rand()%100+1;
	//printf("%d",random);
	do
	{
		if(gussed != random && gusses>0)
		{
			if(gussed<random)
			{
				printf("Number is too low , plese enter higher : \n");
				scanf("%d",&gussed);
			}
			else if(gussed>random)
			{
				printf("Number is too higher , plese enter lower : \n");
				scanf("%d",&gussed);
			}
			else
			{
				break;
			}
		}
		else
		{
			printf("Gusse the Number : \n");
			scanf("%d",&gussed);
			if(gussed==random)
			{
				gusses=1;
				break;
				
			}
		}
		
		gusses+=1;
	}while(gussed!=random);
	printf("\n\n\n\n******  Correct Gusse  ******");
	printf("\n\nYou gussed correct number in %d gusses ",gusses);
	
	return 0;
	}

﻿// if else in one line
#include <stdio.h>

int main(){
	int num;
	printf("Enter number : ");
	scanf("%d",&num);
	(num<5)?printf("\nNumber is less than 5"):printf("\nNumber is not less than 5");
	
	return 0;
	}
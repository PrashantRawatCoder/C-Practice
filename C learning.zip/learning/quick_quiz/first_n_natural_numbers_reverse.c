﻿// firast n natural numbers

#include <stdio.h>
int main(){
	int num;
	printf("Enter number : ");
	scanf("%d",&num);
	for(int a=num;a;a--)
	{
		printf("\n %d",a);
	}
	
	return 0;
	}

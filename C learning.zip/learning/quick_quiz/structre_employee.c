﻿#include <stdio.h>
#include <string.h>

struct emp
{
	int code;
	float salry;
	char name[];
};


int main(){
	struct emp e1;
	strcpy(e1.name,"me");
	e1.code=001;
	e1.salry=500.00;
	struct emp e2;
	strcpy(e2.name,"me");
	e2.code=001;
	e2.salry=500.00;
	struct emp e3;
	strcpy(e3.name,"me");
	e3.code=001;
	e3.salry=500.00;
	printf("%s",e1.name);
	
	}
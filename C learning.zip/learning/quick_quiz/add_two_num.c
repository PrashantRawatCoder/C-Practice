﻿#include <stdio.h>

int main(){
	int a=50;
	int b=7;
	
	printf("this is first method :\n");
	printf("a + b is %d \n",a+b);
	
	printf("\nthis is second method :\n");
	
	int c=a+b;
	printf("a + b is %d \n",c);
	
	return 0;
	}
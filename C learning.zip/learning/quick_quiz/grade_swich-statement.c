﻿// 
#include <stdio.h>

int main(){
	int grade;
	printf("Enter your grade : ");
	scanf("%d",&grade);
	switch(grade)
	{
		case 90:
		printf("A grade");
		break;
		case 80:
		printf("B grade");
		break;
		}
	return 0;
	}
	
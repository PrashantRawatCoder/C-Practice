﻿#include<stdio.h>
#include<math.h>

int main()
{
	float  l;
	printf("Enter length of square : ");
	scanf("%f",&l);
	float area = pow(l,2.0);
	printf("\nArea of square is %f\n",area);
	
	return 0;
}
﻿#include <stdio.h>

void print_array(int *arr){
	int a=0;
	printf("\n\n\n");
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			printf("%d  ",*(arr+a));
			a+=1;
		}
		printf("\n");
	}
	
	}

int main(){
	int arr[3][3];
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			printf("Enter Value of %d in %d : ",1+j,i+1);
			scanf("%d",&arr[i][j]);
		}
	}
	print_array(&arr[0][0]);
	
	
	return 0;
	}
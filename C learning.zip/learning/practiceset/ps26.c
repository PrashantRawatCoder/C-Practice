﻿#include <stdio.h>
void does_not_change_value_of_n_in_main(int n);

int main(){
	
	int n=10;
	printf("Value of n in main before running function : %d\n",n);
	does_not_change_value_of_n_in_main(n);
	printf("Value of n in main after running function : %d\n",n);
	
	
	
	return 0;
	}
	
	
void does_not_change_value_of_n_in_main(int n){
	printf("\n\n\nValue of n in function before opration : %d\n",n);
	n*=10;
	printf("Value of n in function after opration : %d\n\n\n\n",n);
	
	
	}
﻿#include <stdio.h>

int main(){
	FILE *ptr,*ptr2,*ptr3;
	ptr = fopen("a.txt", "r");
	ptr2 = fopen("b.txt", "w");
	ptr3 = fopen("c.txt", "w");
	
	char c=fgetc(ptr);
	printf("writing ......");
	while(c!='n')
	{
		fputc(c,ptr2);
		c=fgetc(ptr);
	}
	printf("wrritend !");
	
	return 0;
	}

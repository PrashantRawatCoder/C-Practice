﻿/*#include <stdio.h>
int main(){
	int i1,i2,i3;
	FILE *fil;
	fil = fopen("int.txt", "r");
	fscanf(fil,"%d",&i1);
	printf("%d\n",i1);
	fclose(fil);
	
	return 0;
	}
*/
#include<stdio.h>

int main() {

	int a, b, c;
	printf("The values of a b and c is %d %d %d\n", a, b, c);
	FILE *ptr;

	ptr = fopen("int.txt", "r");
	

	fscanf(ptr, "%d %d %d", &a, &b, &c);

	printf("The values of a b and c is %d %d %d\n", a, b, c);
	
	return 0;

}

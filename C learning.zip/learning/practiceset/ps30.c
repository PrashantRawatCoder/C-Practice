﻿#include <stdio.h>

typedef struct vector
 {
 	int x;
 	int y;
 } vector ;
 
 int main(){
 	vector v1,v2;
 	v1.x=15;
 	v1.y=16;
 	printf("v1.x = %d  v1.y = %d \n\n\n",v1.x,v1.y);
 	
 	v2.x=25;
 	v2.y=26;
 	printf("v2.x = %d  v2.y = %d \n",v2.x,v2.y);
 	
 	
 	
 	
 	return 0;
 	}

﻿// volume of clyender
#include <stdio.h>

int main(){
	float r , h , area , pi = 3.14159265359
;
	printf("Enter radius of clyender: ");
	scanf("%f",&r);
	printf("Enter height of clyender: ");
	scanf("%f",&h);
	area = pi*r*r*h ;
	printf("Volume of clyender is : %f",area);
	return 0;
	}

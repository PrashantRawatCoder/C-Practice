﻿#include <stdio.h>
#include <string.h>
typedef struct bank
 {
 	int ac;
 	char name[50];
 	float rs;
 	
 } ac;
 
 void dis(ac ac1){
 	printf("Name is : %s\n",ac1.name);
 	printf("AC is : %d\n",ac1.ac);
 	printf("RS is : %f\n",ac1.rs);
 	}
int main(){
	
	ac a1;
	
	printf("Enter your Name : ");
	gets(a1.name);
	printf("Enter your AC : ");
	scanf("%d",&a1.ac);
	printf("Enter your RS : ");
	scanf("%f",&a1.rs);
	
	dis(a1);
	
	
	
	
	
	
	return 0;
	}
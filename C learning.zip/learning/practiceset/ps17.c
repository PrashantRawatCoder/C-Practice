﻿#include <stdio.h>


int main(){
	
	return 0;
	}

int cf(int n);
int cf(int n){
	if(n==13)
	{
		return n;
	}
	return ;
	}
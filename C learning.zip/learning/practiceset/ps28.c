﻿#include <stdio.h>


void rev_arr(int *arr,int size)
{
	for(int i=0;i<(size/2);i++)
	{
	
	int a=*(arr+i);
	
	*(arr+i)=*(arr+(size-(i+1)));
	*(arr+(size-(i+1)))=a;	
	}
	}

	
	
	
	
int main(){
	int arr[10]={1,2,3,4,5,6,7,8,9};
	for(int i=0;i<9;i++)
	{
		printf("%d\n",arr[i]);
	}
	
	rev_arr(&arr[0], 9);
	printf("\n\nRevrse array of this is : \n\n\n\n");
	for(int i=0;i<9;i++)
	{
		printf("%d\n",arr[i]);
	}
	
	
	
	
	return 0;
	}
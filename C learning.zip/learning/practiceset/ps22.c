﻿// pointers #1
#include <stdio.h>
int main(){
	int a=50,*b=&a;
	printf("Value of a is %d and addres of a is %u \n",a,b);
	printf("Value of a is %d \n",*b);
	
	return 0;
	}

﻿#include <stdio.h>

typedef struct vector
 {
 	int x;
 	int y;
 } vector ;
 
 int main(){
 	vector v1,*v2;
 	v1.x=15;
 	v1.y=16;
 	printf("v1.x = %d  v1.y = %d \n\n\n",v1.x,v1.y);
 	v2=&v1;
 	v2->x=50;
 	printf("v1.x = %d  v1.y = %d \n\n\n",v1.x,v1.y);
 	v2->y=50;
 	
 	printf("v1.x = %d  v1.y = %d \n\n\n",v1.x,v1.y);
 	
 	return 0;
 	}

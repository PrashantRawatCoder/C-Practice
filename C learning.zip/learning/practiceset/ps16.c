﻿// celcius to ferenhight 
#include <stdio.h>

float ctof(float c);
int main(){
	float c , f ;
	printf("Enter value of celcius:");
	scanf("%f",&c);
	f=ctof(c);
	printf("Value of Fahrenheit is %f",f);
	return 0;
	}

float ctof(float c){
	float f;
	f=(float)(c*9/5) + 32;
	return f;
	}

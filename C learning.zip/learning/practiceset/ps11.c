﻿// 97-122 = a-z
#include <stdio.h>

int main(){
	char charecter;
	printf("Enter a leeter : \n");
	scanf("%c",&charecter);
	
	if(charecter<=122 && charecter>=97)
	{
		printf("%c is lowercase ",charecter);
	}
	else
	{
		printf("%c is not lowercase ",charecter);
	}
	
	return 0 ;
	}
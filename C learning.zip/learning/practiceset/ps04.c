﻿// celcius to ferenhight 
#include <stdio.h>

int main(){
	float c , f ;
	printf("Enter value of celcius:");
	scanf("%f",&c);
	f=(c*9/5) + 32;
	printf("Value of Fahrenheit is %f",f);
	return 0;
	}

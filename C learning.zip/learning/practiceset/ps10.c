﻿// Which num is  greater

#include <stdio.h>

int main(){
	int n1 , n2,n3,n4;
	printf("Enter first num : ");
	scanf("%d",&n1);
	printf("\nEnter second num : ");
	scanf("%d",&n2);
	printf("\nEnter third num : ");
	scanf("%d",&n3);
	printf("\nEnter fourth num : ");
	scanf("%d",&n4);
	if(n1>n2 && n1>n3 && n1>n4)
	{
		printf("%d is greater than all \n",n1);
	}
	else if(n2>n3 && n2>n4)
	{
		printf("%d is greater than all \n",n2);
	}
	else if(n3>n4)
	{
		printf("%d is greater than all \n",n3);
	}
	else
	{
		printf("\n%d is greater than all \n",n4);
	}
	return 0;
	}

﻿// make a function to find average of any three numbers
#include <stdio.h>

int avrage(int n1,int n2,int n3);
int main(){
	printf("%d",avrage(10, 11, 9));
	return 0;
}

int avrage(int n1,int n2,int n3){
	int avrage=(n1+n2+n3)/3;
	return avrage;
	}

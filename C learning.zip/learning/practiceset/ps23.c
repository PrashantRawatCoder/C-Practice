﻿#include <stdio.h>
void addr(int i);
int main(){
	int i =68;
	printf("Addres of i in main is %u \n",&i);
	addr(i);
	return 0;
	}
	
void addr(int i){
	printf("Addres of i in addr function is %u \n",&i);
	
	
	}
﻿// print multipication table of n
#include <stdio.h>
int main(){
	int n;
	printf("Enter any number ");
	scanf("%d",&n);
	for(int i=1;i<11;i++)
	{
		printf("\n%d",n*i);
	}
	
	
	return 0;
	}
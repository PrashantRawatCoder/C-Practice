﻿#include <stdio.h>
void mulby10(int *n);
int main(){
	int j=10;
	printf("%d\n",j);
	mulby10(&j);
	printf("%d\n",j);
	
	
	return 0;
	}
	

void mulby10(int *n){
	*n *= 10;
	
	}
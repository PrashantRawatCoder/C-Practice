﻿#include <stdio.h>
int main(){
	int n;
	printf("Enter number of lines : ");
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		printf("\n");
		for(int j=0;j<i;j++)
		{
			printf("*");
		}
	}
	
	return 0;
	}

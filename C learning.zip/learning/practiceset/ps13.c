﻿// print revrse multipication table of n
#include <stdio.h>
int main(){
	int n;
	printf("Enter any number ");
	scanf("%d",&n);
	for(int i=10;i;i--)
	{
		printf("\n%d",n*i);
	}
	
	
	return 0;
	}

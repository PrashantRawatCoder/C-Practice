﻿#include <stdio.h>

typedef struct complex
 {
 	int real;
 	int com;
 } complex ;
 
 int main(){
 	
 	complex x[5];
 	
 	for(int i=0;i<5;i++)
 	{
 		printf("Enter value of real in complex[%d] : ",i);
 		scanf("%d",&x[i].real);
 		printf("Enter value of com in complex[%d] : ",i);
 		scanf("%d",&x[i].com);
 	}
 	for(int i=0;i<5;i++)
 	{
 		printf("value of real in complex[%d] is : %d\n",i,x[i].real);
 	
 		printf("value of com in complex[%d] is : %d \n\n",i,x[i].com);
 		
 	}
 	
 	
 	return 0;
 	}

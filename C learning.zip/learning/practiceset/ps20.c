﻿// first n febunati seriese
#include <stdio.h>


int fbn(int n);

int main(){
	int n;
	printf("Enter any number : ");
	scanf("%d",&n);
	printf("\nFirst %d 	\n",fbn(n));
	
	return 0;
	}

int fbn(int n){
	int x;
	if( n==x)
	{
		return n;
	}
	
	return fbn(n-1);
	}

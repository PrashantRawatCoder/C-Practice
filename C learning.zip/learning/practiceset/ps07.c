﻿// Fali or pass

#include <stdio.h>

int main(){
	float sub1 , sub2 , sub3 , total_persent;
	printf("Enter persent of your 1st subject : ");
	scanf("%f",&sub1);
	printf("Enter persent of your 2nd subject : ");
	scanf("%f",&sub2);
	printf("Enter persent of your 3rd subject : ");
	scanf("%f",&sub3);
	
	total_persent=(sub1+sub2+sub3)/300*100;
	
	if(sub1<33)
	{
		printf("You Fali in 1st subject with marks of %f !\n",sub1);
		printf("Total persent is %f \n",total_persent);
	}
	if(sub2<33)
	{
		printf("You Fali in 2nd subject with marks of %f !\n",sub2);
		printf("Total persent is %f \n",total_persent);
	}
	if(sub3<33)
	{
		printf("You Fali in 3rd subject with marks of %f !\n",sub3);
		printf("Total persent is %f \n",total_persent);
	}
	if(total_persent<40)
	{
		printf("You Fali with Total persent of %f !\n",total_persent);
		
	}
	if(total_persent>40 && sub1>33 && sub2>33 && sub3>33 )
	{
		printf("You Passed with Total persent of %f !\n",total_persent);
	}
	return 0;
	}

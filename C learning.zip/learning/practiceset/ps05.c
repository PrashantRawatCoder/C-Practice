﻿// SimpleInstest
#include <stdio.h>

int main(){
	float p , r, y , si , tv ;
	printf("Enter value of princelpal :");
	scanf("%f",&p);
	printf("Enter value of rate :");
	scanf("%f",&r);
	printf("Enter value of years :");
	scanf("%f",&y);
	si= (p*r*y)/100;
	tv=p+si;
	printf("Value of SimpleInstest is %f\n",si);
	printf("Total value you have to pay is %f",tv);
	return 0;
	}

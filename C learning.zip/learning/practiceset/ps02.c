﻿//area of circle 
#include <stdio.h>

int main(){
	float r , area , pi = 3.14159265359
;
	printf("Enter radius of circle : ");
	scanf("%f",&r);
	area = pi*r*r;
	printf("Area of circle is : %f",area);
	return 0;
	}

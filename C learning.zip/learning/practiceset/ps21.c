﻿#include <stdio.h>
void pstar(int n);

int main(){
	int n;
	printf("Enter number lines : ");
	scanf("%d",&n);
	pstar(n);
	return 0;
	}



void pstar(int n){
		for(int i=1;i<=n;i++)
		{
			printf("\n");
			for(float j=0;j<=i-1;j+=0.5)
			{
				printf("*");
			}
		}
	
	}

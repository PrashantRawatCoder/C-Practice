﻿#include <stdio.h>
int main(){
	int a=10,*b=&a,**c=&b;
	printf("value of a is %d ",**(c));
	
	return 0;
	}
﻿#include <stdio.h>


void count_arr(int *arr,int size)
{
	for(int i=0;i<size;i++)
	{
		if( *(arr+i)%2 == 0)
		{
			printf("%d element of array %d is even \n",i+1,*arr+i);
		}
		
		
		
	}
	
	}

	
	
	
	
int main(){
	int arr[9]={1,2,3,4,5,6,7,8,9};
	count_arr(&arr[0], 9);
	
	
	
	
	return 0;
	}

﻿// sum of first n numbers using while loop

#include <stdio.h>
int main(){
	int i =1,n=0,num;
	printf("Enter any number ");
	scanf("%d",&num);
	while(i<=num)
	{
		n+=i;
		i++;
	}
	printf("\n Sum of first %d numbers is %d\n",num,n);
	return 0;
	}
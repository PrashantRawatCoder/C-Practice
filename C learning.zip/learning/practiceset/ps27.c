﻿#include <stdio.h>
int main(){
	int n;
	printf("Enter any num for table : ");
	scanf("%d",&n);
	int arr[10];
	for(int i = 1;i<11;i++)
	{
		arr[i]=n*i;
	}
	for(int i = 1;i<11;i++)
	{
		printf("%d\n",arr[i]);
	}

	return 0;
	}

﻿// sum of first n numbers using rescurcion
#include <stdio.h>


int sum(int n);

int main(){
	int n;
	printf("Enter any number : ");
	scanf("%d",&n);
	printf("\nSum of first %d nutral numbers is %d\n",n , sum(n));
	
	return 0;
	}

int sum(int n){
	if(n==1 || n==0)
	{
		return n;
	}
	
	return n+ sum(n-1);
	}

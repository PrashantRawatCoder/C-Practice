﻿// calculate income tax

#include <stdio.h>

int main(){
	float income,tax;
	printf("Enter your income : ");
	scanf("%f",&income);
	if(income<250000)
	{
		printf("\nYour income is less than 2.5 Lakh , So you do not have to pay any income tax ");
	}
	else if(income>=250000 && income <= 500000)
	{
		tax=tax+0.05*(income-250000);
		printf("\nYou have to pay 5 persent tax which is %f \n",tax);
	}
	else if(income > 500000 && income<=1000000)
	{
		tax= tax + 0.20 * (income-500000);
		printf("\nYou have to pay 20 persent tax which is %f \n",tax);
	}
	else
	{
		tax=tax+0.30*(income-1000000);
		printf("\nYou have to pay 30 persent tax which is %f \n",tax);
	}
	
	return 0;
	}

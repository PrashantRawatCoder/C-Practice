﻿#include <stdio.h>
#include <math.h>

int main(){
	float  k = 3.0/9;
	printf("%f\n",k);
	printf("%d",k);
	return 0;
	}
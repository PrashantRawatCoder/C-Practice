﻿#include <stdio.h>

int main(){
	printf("radhe krishna");
	return 0 ;
	}

﻿#include <stdio.h>
int main()
{
	int i=636;
	int *j=i;
	printf("%u\n",j);
	printf("%u\n",&i);
	
	
	
	return 0;
	}
